# Tahsin Khel Welfare - Native Android Application (Kotlin + Jetpack Compose)

**Package Name:** `com.tahsinkhel.welfare`  
**Application ID:** `com.tahsinkhel.welfare`  
**UI Framework:** Jetpack Compose (Material 3)  
**Language:** Kotlin 2.0+  
**Min SDK:** 24 (Android 7.0+)  
**Target SDK:** 35 (Android 15)  

---

## 📱 How to Build the Working APK

### Method 1: Android Studio (Recommended)
1. Open **Android Studio** (Ladybug or newer).
2. Click **Open** and select the `/android` directory of this repository.
3. Allow Gradle to sync dependencies.
4. Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be generated at:  
   `app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Command Line (Terminal)
Run the following commands in the `/android` directory:

```bash
# Make gradlew executable
chmod +x gradlew

# Build Debug APK
./gradlew assembleDebug
```

The APK file will be available at:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🎨 Features & Architecture
- **Urdu & English Localization:** Fully localized in `res/values/strings.xml` and `res/values-ur/strings.xml`.
- **24/7 Helpline:** Direct phone dialing for emergency funeral assistance to `03463553900`.
- **System Calculated Financial Transparency:** Fully transparent ledger views.
- **Member Directory:** Real-time search by member name, membership number, or village.
- **Admin Panel:** Management controls and village tracking.
