# ProGuard rules for Tahsin Khel Welfare Android App
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}
