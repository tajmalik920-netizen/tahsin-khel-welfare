package com.tahsinkhel.welfare.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald800 = Color(0xFF166534)
val Emerald700 = Color(0xFF15803D)
val Emerald900 = Color(0xFF14532D)
val Emerald950 = Color(0xFF052E16)

val Amber500 = Color(0xFFF59E0B)
val Amber600 = Color(0xFFD97706)
val Amber400 = Color(0xFFFBBF24)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
