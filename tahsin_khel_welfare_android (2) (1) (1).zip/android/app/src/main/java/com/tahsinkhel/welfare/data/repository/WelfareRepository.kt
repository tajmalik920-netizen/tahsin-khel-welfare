package com.tahsinkhel.welfare.data.repository

import com.tahsinkhel.welfare.data.models.*

object WelfareRepository {
    val organizationInfo = OrganizationInfo()

    val villages = listOf(
        Village("1", "باندہ", "Banda"),
        Village("2", "شنگلی", "Shangli"),
        Village("3", "مٹور", "Matore"),
        Village("4", "درہ", "Darra"),
        Village("5", "کنڈ", "Kund"),
        Village("6", "ڈھوک", "Dhok"),
        Village("7", "سرسبز", "Sarsabz")
    )

    val sampleMembers = listOf(
        Member(
            id = "m-1",
            membershipNo = "TK-101",
            name = "تاج محمد خان",
            fatherName = "محمد سرور خان",
            phone = "03463553900",
            village = "باندہ",
            role = "admin"
        ),
        Member(
            id = "m-2",
            membershipNo = "TK-102",
            name = "محمد اکرم",
            fatherName = "عبدالرشید",
            phone = "03442022120",
            village = "شنگلی",
            role = "member"
        ),
        Member(
            id = "m-3",
            membershipNo = "TK-103",
            name = "عبدالغفور",
            fatherName = "نور زمان",
            phone = "03451234567",
            village = "مٹور",
            role = "member"
        )
    )

    val sampleCases = listOf(
        EmergencyCase(
            id = "c-1",
            caseNumber = "EMG-2026-01",
            title = "میت ایمبولینس و منتقلی تعاون",
            personName = "مرحوم عبدالرحمٰن",
            assistanceType = "میت فنڈ",
            amountGranted = 25000,
            status = "مکمل",
            date = "2026-08-15"
        ),
        EmergencyCase(
            id = "c-2",
            caseNumber = "EMG-2026-02",
            title = "ہنگامی ہسپتال و علاج معاونت",
            personName = "گل رحمان",
            assistanceType = "طبی امداد",
            amountGranted = 15000,
            status = "مکمل",
            date = "2026-09-02"
        )
    )

    val samplePayments = listOf(
        PaymentRecord(
            id = "p-1",
            receiptNo = "RCP-1001",
            memberId = "m-1",
            memberName = "تاج محمد خان",
            amount = 500,
            monthYear = "2026-08",
            date = "2026-08-01"
        ),
        PaymentRecord(
            id = "p-2",
            receiptNo = "RCP-1002",
            memberId = "m-2",
            memberName = "محمد اکرم",
            amount = 500,
            monthYear = "2026-08",
            date = "2026-08-05"
        )
    )
}
