package com.tahsinkhel.welfare.data.models

data class Member(
    val id: String,
    val membershipNo: String,
    val name: String,
    val fatherName: String,
    val phone: String,
    val cnic: String = "",
    val village: String,
    val role: String = "member",
    val status: String = "active",
    val monthlyContribution: Int = 500
)

data class PaymentRecord(
    val id: String,
    val receiptNo: String,
    val memberId: String,
    val memberName: String,
    val amount: Int,
    val monthYear: String,
    val date: String,
    val method: String = "Cash"
)

data class EmergencyCase(
    val id: String,
    val caseNumber: String,
    val title: String,
    val personName: String,
    val assistanceType: String,
    val amountGranted: Int,
    val status: String,
    val date: String
)

data class OrganizationInfo(
    val nameUr: String = "تحسن خیل فلاحی تنظیم",
    val nameEn: String = "Tahsin Khel Welfare Organization",
    val sloganUr: String = "خدمت خلق عبادت ہے",
    val sloganEn: String = "Service to Humanity is Worship",
    val tribeRegionUr: String = "تحسن خیل قبائل اکازئی، ضلع تورغر",
    val tribeRegionEn: String = "Tahsin Khel Tribes Akazai, District Torghar",
    val helplinePhone: String = "03463553900",
    val emergencyHelpline: String = "03463553900",
    val phone: String = "03442022120",
    val whatsapp: String = "03442022120",
    val email: String = "info@tahsinkhelwelfare.org",
    val monthlyContributionRate: Int = 500
)

data class Village(
    val id: String,
    val nameUr: String,
    val nameEn: String
)
