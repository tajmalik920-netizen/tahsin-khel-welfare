package com.tahsinkhel.welfare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tahsinkhel.welfare.ui.screens.*
import com.tahsinkhel.welfare.ui.theme.TahsinKhelWelfareTheme

sealed class Screen(val route: String, val titleUr: String, val icon: ImageVector) {
    object Home : Screen("home", "ہوم", Icons.Default.Home)
    object Membership : Screen("membership", "رکنیت", Icons.Default.People)
    object Emergency : Screen("emergency", "ہنگامی 24/7", Icons.Default.Emergency)
    object Reports : Screen("reports", "رپورٹس", Icons.Default.Assessment)
    object Admin : Screen("admin", "ایڈمن", Icons.Default.AdminPanelSettings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TahsinKhelWelfareTheme {
                val navController = rememberNavController()
                val items = listOf(
                    Screen.Home,
                    Screen.Membership,
                    Screen.Emergency,
                    Screen.Reports,
                    Screen.Admin
                )

                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar {
                            items.forEach { screen ->
                                NavigationBarItem(
                                    icon = { Icon(screen.icon, contentDescription = screen.titleUr) },
                                    label = { Text(screen.titleUr) },
                                    selected = currentRoute == screen.route,
                                    onClick = {
                                        if (currentRoute != screen.route) {
                                            navController.navigate(screen.route) {
                                                popUpTo(Screen.Home.route) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Home.route) {
                            HomeScreen(onNavigate = { route ->
                                navController.navigate(route)
                            })
                        }
                        composable(Screen.Membership.route) {
                            MembershipScreen(onBack = {
                                navController.popBackStack()
                            })
                        }
                        composable(Screen.Emergency.route) {
                            EmergencyScreen(onBack = {
                                navController.popBackStack()
                            })
                        }
                        composable(Screen.Reports.route) {
                            ReportsScreen(onBack = {
                                navController.popBackStack()
                            })
                        }
                        composable(Screen.Admin.route) {
                            AdminScreen(onBack = {
                                navController.popBackStack()
                            })
                        }
                    }
                }
            }
        }
    }
}
