package com.tahsinkhel.welfare.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tahsinkhel.welfare.data.models.Member
import com.tahsinkhel.welfare.data.repository.WelfareRepository
import com.tahsinkhel.welfare.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MembershipScreen(onBack: () -> Unit) {
    var searchQuery by remember { mutableStateOf("") }
    val members = WelfareRepository.sampleMembers.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.membershipNo.contains(searchQuery, ignoreCase = true) ||
        it.village.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("رکنیت اور ممبرز لسٹ", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Emerald800,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Slate50)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("نام، ممبرشپ نمبر یا گاؤں تلاش کریں...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(12.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(members) { member ->
                    MemberCard(member = member)
                }
            }
        }
    }
}

@Composable
fun MemberCard(member: Member) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Emerald800.copy(alpha = 0.1f),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Badge, contentDescription = null, tint = Emerald800)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = member.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
                Text(text = "ولدیت: ${member.fatherName}", fontSize = 12.sp, color = Slate600)
                Text(text = "گاؤں: ${member.village} • رابطہ: ${member.phone}", fontSize = 11.sp, color = Slate600)
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Amber400.copy(alpha = 0.2f)
            ) {
                Text(
                    text = member.membershipNo,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Amber600,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
